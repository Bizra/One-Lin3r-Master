class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List current routing table"
    function    = "PrivEsc"
    liner       = 'route print'
