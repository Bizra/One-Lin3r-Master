class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all services using wmic."
    function    = "PrivEsc"
    liner       = 'wmic service list brief'
