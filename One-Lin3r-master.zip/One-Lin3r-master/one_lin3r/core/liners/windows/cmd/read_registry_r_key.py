class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Query the Local machine R key from the registry"
    function    = "PrivEsc"
    liner       = 'reg query HKLM\Software\Microsoft\Windows\CurrentVersion\R'
