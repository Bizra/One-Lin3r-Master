class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using the .NET compiler to compile a c# liner locally that can then be executed."
    function    = "Execute"
    liner     = "C:\Windows\Microsoft.NET\Framework\\v2.0.50727\csc.exe /out:liner.exe FILE_PATH"
