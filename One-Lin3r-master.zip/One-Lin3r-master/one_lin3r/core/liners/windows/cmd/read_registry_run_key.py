class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Query run key from the registry for the current user ofc."
    function    = "PrivEsc"
    liner       = 'reg query HKCU\Software\Microsoft\Windows\CurrentVersion\Run'
