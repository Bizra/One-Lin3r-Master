class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List firewall state and current configuration using netsh"
    function    = "PrivEsc"
    liner       = 'netsh firewall show state & netsh firewall show config'
