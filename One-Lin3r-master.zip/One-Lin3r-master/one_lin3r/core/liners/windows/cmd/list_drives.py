class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all drives using wmic"
    function    = "PrivEsc"
    liner       = 'wmic logicaldisk get caption,description,providername'
