class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all current connections"
    function    = "PrivEsc"
    liner       = 'netstat -ano'
