class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List the ARP table"
    function    = "PrivEsc"
    liner       = 'arp -A'
