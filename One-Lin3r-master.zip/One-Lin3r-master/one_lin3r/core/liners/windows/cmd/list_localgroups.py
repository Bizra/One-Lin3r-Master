class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all local groups"
    function    = "PrivEsc"
    liner       = 'net localgroup'
