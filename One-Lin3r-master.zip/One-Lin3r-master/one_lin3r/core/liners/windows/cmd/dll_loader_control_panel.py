class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using windows's control panel to load a dll file!"
    function    = "Loader"
    liner     = """control.exe FILE_PATH"""
