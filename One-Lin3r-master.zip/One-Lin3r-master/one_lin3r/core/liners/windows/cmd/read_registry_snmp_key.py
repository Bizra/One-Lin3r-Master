class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Query the Local machine snmp key from the registry to get snmp parameters"
    function    = "PrivEsc"
    liner       = 'reg query "HKLM\SYSTEM\Current\ControlSet\Services\SNMP"'
