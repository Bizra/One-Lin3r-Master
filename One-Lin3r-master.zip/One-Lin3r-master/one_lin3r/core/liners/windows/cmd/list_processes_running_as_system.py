class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Get processes that's running as system"
    function    = "PrivEsc"
    liner       = 'tasklist /v /fi "username eq system"'
