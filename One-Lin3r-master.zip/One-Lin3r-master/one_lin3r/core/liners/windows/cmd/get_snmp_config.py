class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Get current SNMP Configuration"
    function    = "PrivEsc"
    liner       = 'reg query HKLM\SYSTEM\CurrentControlSet\Services\SNMP /s'
