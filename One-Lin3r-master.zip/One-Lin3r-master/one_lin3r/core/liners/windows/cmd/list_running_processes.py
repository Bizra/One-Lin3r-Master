class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Get running processes"
    function    = "PrivEsc"
    liner       = 'tasklist /v'
