class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Query the Local machine winlogon key from the registry for windows autologin"
    function    = "PrivEsc"
    liner       = 'reg query "HKLM\SOFTWARE\Microsoft\Windows NT\Currentversion\Winlogon"'
