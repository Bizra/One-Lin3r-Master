class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Using nmap to launch a ftp bruteforce attack."
    function    = "Nmap script"
    liner       = "nmap --script ftp-brute -p 21 TARGET"
