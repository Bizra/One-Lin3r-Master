class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Search for 'password' string in memory"
    function    = "PrivEsc"
    liner       = 'strings /dev/mem -n10 | grep -i PASS'
