class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Read all apache 'site-enabled' directory files"
    function    = "PrivEsc"
    liner       = 'cat /etc/apache2/site-enabled/*'
