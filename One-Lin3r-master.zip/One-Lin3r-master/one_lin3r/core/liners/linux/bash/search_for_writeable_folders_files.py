class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Search a directory for writeable files and directories using find"
    function    = "PrivEsc"
    liner       = 'find FILE_PATH -perm -o+w'
