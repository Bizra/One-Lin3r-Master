class info:
    author      = "Karim shoair (D4Vinci)"
    description = "Read bash history files for all users"
    function    = "PrivEsc"
    liner       = 'cat /home/*/.bash_history'
