class info:
    author      = "Karim shoair (D4Vinci)"
    description = "List all crob jobs for another user"
    function    = "PrivEsc"
    liner       = 'crontab -u USERNAME -l'
