class info:
    author      = "ZonkSec"
    description = "run an ad hoc http static server in your current directory (python3)"
    function    = "Dropper"
    liner     = """python -m http.server PORT"""
