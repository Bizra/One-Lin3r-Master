class info:
    author      = "Karim shoair (D4Vinci)"
    description = "The alternative for sudo for openbsds, most of the times you gonna find interesting things in doas config."
    function    = "PrivEsc"
    liner       = 'cat /etc/doas.conf'
