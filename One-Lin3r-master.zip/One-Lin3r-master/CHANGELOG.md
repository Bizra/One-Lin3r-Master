## 2.1
- Fixed the Unicode conflict in windows.
- Fixed the modules path problem in windows that was causing the **ModuleNotFound** error.
- Fixed check for update feature.
- Added new options to search command, now search is more accurate and deep.
- Added more information about how to install the framework more easily.
- Added 21 new liners to become the total number of liners now is 176 liner.

## 2.0
- A full rewrite of the framework with a lot of improvements. If you have older version, please update.
- Added 125 new liners.
